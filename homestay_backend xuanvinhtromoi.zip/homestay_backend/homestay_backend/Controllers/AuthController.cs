﻿using homestay_backend.Data;
using homestay_backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace homestay_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly string _secretKey = "HomstaySecretKeyHomstaySecretKey123";
        private readonly string _issuer = "Homstay";
        private readonly string _audience = "Homstay";
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("Register")]
        public IActionResult Register([FromBody] Register registerModel)
        {
            if (registerModel == null)
            {
                return BadRequest(new { Message = "Dữ liệu không hợp lệ." });
            }

            var existingUser = _context.Users.FirstOrDefault(u => u.Email == registerModel.Email || u.PhoneNumber == registerModel.PhoneNumber);

            if (existingUser != null)
            {
                return BadRequest(new { Message = "Tài khoản đã tồn tại." });
            }

            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(registerModel.Password);

            var user = new Users
            {
                Email = registerModel.Email,
                FullName = registerModel.FullName,
                PhoneNumber = registerModel.PhoneNumber,
                Role = registerModel.Role,
                PasswordHash = hashedPassword
            };

            _context.Users.Add(user);

            _context.SaveChanges();


            return Ok(new { Message = "Đăng ký tài khoản thành công" });
        }

        [HttpPost("Login")]
        public IActionResult Login([FromBody] Login loginModel)
        {
            if (loginModel == null)
            {
                return BadRequest(new { Message = "Dữ liệu không hợp lệ." });
            }

            var user = _context.Users.FirstOrDefault(u => u.Email == loginModel.Email);

            if (user == null)
            {
                return Unauthorized(new { Message = "Email không tồn tại." });
            }

            bool isPasswordValid = BCrypt.Net.BCrypt.Verify(loginModel.Password, user.PasswordHash);

            if (!isPasswordValid)
            {
                return Unauthorized(new { Message = "Mật khẩu không chính xác." });
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.Email),
                new Claim(ClaimTypes.Name, user.PhoneNumber),
                new Claim(ClaimTypes.Role, user.Role),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _issuer,
                _audience,
                claims,
                expires: DateTime.Now.AddHours(24),
                signingCredentials: creds
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

            return Ok(new { 
                Token = tokenString,
                User = new {
                    user.UserId,
                    user.Email,
                    user.FullName,
                    user.PhoneNumber,
                    user.Role
                }
            });
        }
    }
}
