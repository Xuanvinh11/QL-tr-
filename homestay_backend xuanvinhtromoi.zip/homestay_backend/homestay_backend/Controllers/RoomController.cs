﻿using homestay_backend.Data;
using homestay_backend.Models;
using homestay_backend.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace homestay_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly EmailService _emailService;

        public RoomController(AppDbContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        [HttpGet]
        public async Task<IActionResult> GetRooms(
        [FromQuery] string provinceCode = null,
        [FromQuery] string districtCode = null,
        [FromQuery] string priceRange = null,
        [FromQuery] string area = null,
        [FromQuery] string status = null)
        {
            var query = from room in _context.Rooms
                        join province in _context.Provinces on room.ProvinceCode equals province.Code
                        join district in _context.Districts on room.DistrictCode equals district.Code
                        select new
                        {
                            room.RoomId,
                            room.Name,
                            room.Description,
                            room.Price,
                            room.Area,
                            room.Address,
                            room.Image,
                            room.IsAvailable,
                            room.IsActive,
                            ProvinceName = province.Name,
                            DistrictName = district.Name,
                            ProvinceCode = province.Code,
                            DistrictCode = district.Code
                        };

            if (!string.IsNullOrEmpty(provinceCode))
            {
                query = query.Where(r => r.ProvinceCode == provinceCode);
            }

            if (!string.IsNullOrEmpty(districtCode))
            {
                query = query.Where(r => r.DistrictCode == districtCode);
            }

            if (!string.IsNullOrEmpty(priceRange))
            {
                if (priceRange == "1")
                {
                    query = query.Where(r => r.Price < 3000000);
                }
                else if (priceRange == "2")
                {
                    query = query.Where(r => r.Price >= 3000000 && r.Price <= 5000000);
                }
                else if (priceRange == "3")
                {
                    query = query.Where(r => r.Price > 5000000 && r.Price <= 7000000);
                }
                else if (priceRange == "4")
                {
                    query = query.Where(r => r.Price > 7000000);
                }
            }

            if (!string.IsNullOrEmpty(area))
            {
                if (area == "1")
                {
                    query = query.Where(r => r.Area < 20);
                }
                else if (area == "2")
                {
                    query = query.Where(r => r.Area >= 40 && r.Area <= 60);
                }
                else if (area == "3")
                {
                    query = query.Where(r => r.Area >= 60 && r.Area <= 80);
                }
                else if (area == "4")
                {
                    query = query.Where(r => r.Area > 80);
                }
            }

            if (!string.IsNullOrEmpty(status))
            {
                if (status == "1")
                {
                    query = query.Where(r => r.IsAvailable == 1);
                }
            }

            query = query.Where(r => r.IsActive == 1);

            var rooms = await query.ToListAsync();
            return Ok(rooms);
        }

        [HttpGet("{RoomId}")]
        public async Task<IActionResult> GetRoomById(int RoomId)
        {
            var room = await _context.Rooms
                .Where(r => r.RoomId == RoomId && r.IsActive == 1)
                .Select(r => new
                {
                    r.RoomId,
                    r.Name,
                    r.Description,
                    r.Price,
                    r.Area,
                    r.Address,
                    r.ClosingTime,
                    r.Latitude,
                    r.Longitude,
                    r.Image,
                    r.IsAvailable,
                    r.CreatedAt,
                    r.AllowPet,
                    r.HasAirConditioning,
                    r.NumberOfBedrooms,
                    r.UtilityCost,
                    ProvinceName = r.Province.Name,
                    DistrictName = r.District.Name,
                    ProvinceCode = r.Province.Code,
                    DistrictCode = r.District.Code,
                    OwnerName = r.User.FullName,
                    OwnerPhone = r.User.PhoneNumber,
                    OwnerEmail = r.User.Email
                })
                .FirstOrDefaultAsync();

            if (room == null)
            {
                return NotFound();
            }

            return Ok(room);
        }

        [HttpPost]
        public IActionResult CreateRoom([FromBody] RoomDTO roomDTO)
        {
            if (roomDTO == null)
            {
                return BadRequest(new { Message = "Dữ liệu không hợp lệ." });
            }

            var room = new Rooms
            {
                Name = roomDTO.Name,
                OwnerId = roomDTO.OwnerId,
                Description = roomDTO.Description,
                Price = roomDTO.Price,
                Area = roomDTO.Area,
                Address = roomDTO.Address,
                ClosingTime = roomDTO.ClosingTime,
                Latitude = roomDTO.Latitude,
                Longitude = roomDTO.Longitude,
                Image = roomDTO.Image,
                IsAvailable = 1,
                IsActive = 0,
                ProvinceCode = roomDTO.ProvinceCode,
                DistrictCode = roomDTO.DistrictCode,
                AllowPet = roomDTO.AllowPet,
                HasAirConditioning = roomDTO.HasAirConditioning,
                NumberOfBedrooms = roomDTO.NumberOfBedrooms,
                UtilityCost = roomDTO.UtilityCost,
                CreatedAt = DateTime.UtcNow
            };

            _context.Rooms.Add(room);

            _context.SaveChanges();

            return Ok(new { Message = "Tin của bạn đang chờ xét duyệt" });
        }

        [HttpPut("{RoomId}")]
        public IActionResult UpdateRoom([FromBody] RoomDTO roomDTO, int RoomId)
        {
            if (roomDTO == null)
            {
                return BadRequest(new { Message = "Dữ liệu không hợp lệ." });
            }

            var room = _context.Rooms.FirstOrDefault(r => r.RoomId == RoomId);

            if (room == null)
            {
                return NotFound(new { Message = "Phòng không tồn tại." });
            }

            room.Name = roomDTO.Name;
            room.OwnerId = roomDTO.OwnerId;
            room.Description = roomDTO.Description;
            room.Price = roomDTO.Price;
            room.Area = roomDTO.Area;
            room.Address = roomDTO.Address;
            room.ClosingTime = roomDTO.ClosingTime;
            room.Latitude = roomDTO.Latitude;
            room.Longitude = roomDTO.Longitude;
            room.Image = roomDTO.Image;
            room.IsActive = 0;
            room.ProvinceCode = roomDTO.ProvinceCode;
            room.DistrictCode = roomDTO.DistrictCode;
            room.AllowPet = roomDTO.AllowPet;
            room.HasAirConditioning = roomDTO.HasAirConditioning;
            room.NumberOfBedrooms = roomDTO.NumberOfBedrooms;
            room.UtilityCost = roomDTO.UtilityCost;

            _context.SaveChanges();

            return Ok(new { Message = "Cập nhật thông tin phòng thành công." });
        }


        [HttpGet("{RoomId}/{UserId}")]
        public async Task<IActionResult> GetComments(int RoomId, int UserId)
        {
            var room = await _context.Rooms
            .Where(r => r.RoomId == RoomId)
            .FirstOrDefaultAsync();

            if (room == null)
            {
                return NotFound(new { Message = "Không tìm thấy phòng" });
            }

            var comments = await _context.Comments
            .Where(c => c.RoomId == RoomId &&
                        (c.UserId == UserId || room.OwnerId == UserId))
            .Include(c => c.User)
            .Select(c => new
            {
                c.CommentId,
                c.Content,
                c.CreatedAt,
                FullName = c.User.FullName,
                Email = c.User.Email
            })
            .ToListAsync();

            return Ok(comments);
        }

        [HttpGet("Comment/{OwnerId}")]
        public IActionResult GetCommentsByOwnerId(int OwnerId)
        {
            var comments = _context.Comments
                .Where(c => _context.Rooms.Any(r => r.RoomId == c.RoomId && r.OwnerId == OwnerId))
                .Include(c => c.User)
                .Include(c => c.Room)
                .Select(c => new
                {
                    CommentId = c.CommentId,
                    RoomId = c.RoomId,
                    Content = c.Content,
                    CreatedAt = c.CreatedAt,
                    UserId = c.UserId,
                    FullName = c.User.FullName,
                    Email = c.User.Email,
                    PhoneNumber = c.User.PhoneNumber,
                    RoomName = c.Room.Name
                })
                .ToList();

            return Ok(comments);
        }


        [HttpGet("Owner/{UserId}")]
        public async Task<IActionResult> GetRoomsByUserId(int UserId)
        {
            var rooms = await _context.Rooms
                .Where(r => r.OwnerId == UserId)
                .Select(r => new
                {
                    r.RoomId,
                    r.Name,
                    r.Description,
                    r.Price,
                    r.Area,
                    r.Address,
                    r.ClosingTime,
                    r.Latitude,
                    r.Longitude,
                    r.Image,
                    r.IsAvailable,
                    r.IsActive,
                    r.CreatedAt,
                    r.AllowPet,
                    r.HasAirConditioning,
                    r.NumberOfBedrooms,
                    r.UtilityCost,
                    ProvinceName = r.Province.Name,
                    DistrictName = r.District.Name,
                    ProvinceCode = r.Province.Code,
                    DistrictCode = r.District.Code,
                    OwnerName = r.User.FullName,
                    OwnerPhone = r.User.PhoneNumber,
                    OwnerEmail = r.User.Email
                })
                .ToListAsync();

            return Ok(rooms);
        }


        [HttpPost("Comment")]
        public async Task<IActionResult> AddComment([FromBody] CommentDTO commentDto)
        {
            var comment = new Comments
            {
                RoomId = commentDto.RoomId,
                UserId = commentDto.UserId,
                Content = commentDto.Content,
                CreatedAt = DateTime.UtcNow
            };

            var body = "<h3>Chúng tôi sẽ phản hồi bạn trong thời gian sớm nhất</h1>";

            var user = _context.Users.FirstOrDefault(u => u.UserId == commentDto.UserId);

            if (user == null)
            {
                return NotFound();
            }

            _emailService.SendEmail(user.Email, "Cảm ơn bạn đã để lại bình luận", body);

            _context.Comments.Add(comment);

            await _context.SaveChangesAsync();

            return Ok(new { Message = "Gửi bình luận thành công. Vui lòng kiểm tra hòm thư." });
        }

        [HttpPost("SendEmail")]
        public IActionResult SendEmail([FromBody] EmailRequest emailRequest)
        {
            try
            {
                _emailService.SendEmail(emailRequest.RecipientEmail, emailRequest.Subject, emailRequest.Body);
                return Ok(new { Message = "Email đã được gửi thành công." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = $"Không thể gửi email: {ex.Message}" });
            }
        }

        [HttpGet("NotActivated")]
        public async Task<IActionResult> GetRoomsNotActivated()
        {
            var rooms = await _context.Rooms
               .Where(r => r.IsActive == 0)
               .Select(r => new
               {
                   r.RoomId,
                   r.Name,
                   r.Description,
                   r.Price,
                   r.Area,
                   r.Address,
                   r.ClosingTime,
                   r.Latitude,
                   r.Longitude,
                   r.Image,
                   r.IsAvailable,
                   r.IsActive,
                   r.CreatedAt,
                   r.AllowPet,
                   r.HasAirConditioning,
                   r.NumberOfBedrooms,
                   r.UtilityCost,
                   ProvinceName = r.Province.Name,
                   DistrictName = r.District.Name,
                   ProvinceCode = r.Province.Code,
                   DistrictCode = r.District.Code,
                   OwnerName = r.User.FullName,
                   OwnerPhone = r.User.PhoneNumber,
                   OwnerEmail = r.User.Email
               })
               .ToListAsync();

            return Ok(rooms);
        }

        [HttpPost("Approve/{RoomId}")]
        public IActionResult ApproveRoom(int RoomId)
        {
            var room = _context.Rooms.FirstOrDefault(r => r.RoomId == RoomId);

            if (room == null)
            {
                return NotFound(new { Message = "Không tìm thấy phòng" });
            }

            room.IsActive = 1;

            _context.SaveChanges();

            var body = "<h3>Quản trị viên vừa phê duyệt phòng của bạn</h1>";

            var user = _context.Users.FirstOrDefault(u => u.UserId == room.OwnerId);

            if (user == null)
            {
                return NotFound();
            }

            _emailService.SendEmail(user.Email, "Cập nhật trạng thái", body);

            return Ok(new { Message = "Cập nhật trạng thái thành công." });
        }
    }
}

public class EmailRequest
{
    public string RecipientEmail { get; set; }
    public string Subject { get; set; }
    public string Body { get; set; }
}