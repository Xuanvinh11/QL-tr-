﻿using homestay_backend.Data;
using homestay_backend.Models;
using homestay_backend.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace homestay_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly EmailService _emailService;

        public BookingController(AppDbContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateBooking([FromBody] BookingDTO bookingDTO)
        {
            if (bookingDTO == null)
            {
                return BadRequest("Dữ liệu không hợp lệ.");
            }

            var room = _context.Rooms.Find(bookingDTO.RoomId);
            if (room == null)
            {
                return NotFound("Phòng không tồn tại.");
            }

            var booking = new Bookings
            {
                RoomId = bookingDTO.RoomId,
                UserId = bookingDTO.UserId,
                BookingDate = DateTime.UtcNow,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Bookings.Add(booking);

            await _context.SaveChangesAsync();

            var user = _context.Users.FirstOrDefault(u => u.UserId == bookingDTO.UserId);

            if (user == null)
            {
                return NotFound();
            }

            var body = "<h3>Chúng tôi sẽ phản hồi bạn trong thời gian sớm nhất</h1>";

            _emailService.SendEmail(user.Email, "Đặt phòng thành công", body);

            return Ok(new { Message = "Đặt phòng thành công.", BookingId = booking.Id });
        }

        [HttpGet("{ownerId}")]
        public IActionResult GetBookingsByOwner(int ownerId)
        {
            var bookings = (from b in _context.Bookings
                            join r in _context.Rooms on b.RoomId equals r.RoomId
                            join u in _context.Users on b.UserId equals u.UserId
                            where r.OwnerId == ownerId
                            select new
                            {
                                BookingId = b.Id,
                                CustomerId = b.UserId,
                                CustomerName = u.FullName,
                                CustomerEmail = u.Email,
                                RoomId = r.RoomId,
                                RoomName = r.Name,
                                Status = b.Status,
                                BookingDate = b.CreatedAt
                            }).ToList();

            return Ok(bookings);
        }
    }
}
