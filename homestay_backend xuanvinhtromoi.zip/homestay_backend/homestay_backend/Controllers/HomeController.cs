﻿using homestay_backend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace homestay_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("Provinces")]
        public async Task<IActionResult> GetProvinces()
        {
            var provinces = await _context.Provinces.ToListAsync();
            return Ok(provinces);
        }

        [HttpGet("Provinces/{ProvinceCode}/Districts")]
        public async Task<IActionResult> GetDistrictsByProvince(string ProvinceCode)
        {
            var districts = await _context.Districts
                .Where(d => d.ProvinceCode == ProvinceCode)
                .ToListAsync();

            return Ok(districts);
        }

    }
}
