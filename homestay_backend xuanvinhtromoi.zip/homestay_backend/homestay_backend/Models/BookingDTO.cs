﻿namespace homestay_backend.Models
{
    public class BookingDTO
    {
        public int RoomId { get; set; }
        public int UserId { get; set; }
    }
}
