﻿using System.Text.Json.Serialization;

namespace homestay_backend.Models
{
    public class Rooms
    {
        public int RoomId { get; set; }
        public string Name { get; set; }
        public int OwnerId { get; set; }
        public string Address { get; set; }
        public string ProvinceCode { get; set; }
        public string DistrictCode { get; set; }
        public string Description { get; set; }
        public string ClosingTime { get; set; }
        public string Image { get; set; }
        public double Area { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public decimal Price { get; set; }
        public byte IsAvailable { get; set; }
        public byte IsActive { get; set; }
        public byte AllowPet { get; set; }
        public byte HasAirConditioning { get; set; }
        public int NumberOfBedrooms { get; set; }
        public decimal UtilityCost { get; set; }
        public DateTime CreatedAt { get; set; }

        public Provinces Province { get; set; }
        public Districts District { get; set; }
        public Users User { get; set; }
    }
}
