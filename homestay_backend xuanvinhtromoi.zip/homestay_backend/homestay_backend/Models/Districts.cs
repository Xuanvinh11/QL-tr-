﻿namespace homestay_backend.Models
{
    public class Districts
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string ProvinceCode { get; set; }
    }
}
