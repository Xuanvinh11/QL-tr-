﻿namespace homestay_backend.Models
{
    public class CommentDTO
    {
        public int RoomId { get; set; }
        public int UserId { get; set; }
        public string Content { get; set; }
    }
}
