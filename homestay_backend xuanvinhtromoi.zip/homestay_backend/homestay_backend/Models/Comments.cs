﻿namespace homestay_backend.Models
{
    public class Comments
    {
        public int CommentId { get; set; }
        public int RoomId { get; set; }
        public int UserId { get; set; }
        public string Content { get; set; }
        public DateTime CreatedAt { get; set; }

        public Rooms Room { get; set; }
        public Users User { get; set; }
    }
}
