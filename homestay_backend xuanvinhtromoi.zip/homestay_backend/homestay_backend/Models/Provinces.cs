﻿namespace homestay_backend.Models
{
    public class Provinces
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
