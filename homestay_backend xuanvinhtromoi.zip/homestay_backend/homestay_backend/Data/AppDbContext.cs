﻿using homestay_backend.Models;
using Microsoft.EntityFrameworkCore;

namespace homestay_backend.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Rooms> Rooms { get; set; }
        public DbSet<Provinces> Provinces { get; set; }
        public DbSet<Districts> Districts { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Comments> Comments { get; set; }
        public DbSet<Bookings> Bookings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rooms>(entity =>
            {
                entity.HasKey(r => r.RoomId);
            });

            modelBuilder.Entity<Rooms>()
            .HasOne(r => r.District)
            .WithMany()
            .HasForeignKey(r => r.DistrictCode);

            modelBuilder.Entity<Rooms>()
            .HasOne(r => r.User)
            .WithMany()
            .HasForeignKey(r => r.OwnerId);

            modelBuilder.Entity<Provinces>(entity =>
            {
                entity.HasKey(r => r.Code);
            });

            modelBuilder.Entity<Districts>(entity =>
            {
                entity.HasKey(r => r.Code);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(r => r.UserId);
            });

            modelBuilder.Entity<Comments>(entity =>
            {
                entity.HasKey(r => r.CommentId);
            });

            modelBuilder.Entity<Comments>()
            .HasOne(r => r.Room)
            .WithMany()
            .HasForeignKey(r => r.RoomId);

            modelBuilder.Entity<Comments>()
            .HasOne(r => r.User)
            .WithMany()
            .HasForeignKey(r => r.UserId);

            modelBuilder.Entity<Bookings>(entity =>
            {
                entity.HasKey(r => r.Id);
            });

            modelBuilder.Entity<Bookings>()
            .HasOne(r => r.Room)
            .WithMany()
            .HasForeignKey(r => r.RoomId);

            modelBuilder.Entity<Bookings>()
            .HasOne(r => r.User)
            .WithMany()
            .HasForeignKey(r => r.UserId);
        }
    }
}
