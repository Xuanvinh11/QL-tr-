export const ROLE = {
  ADMIN: "Admin",
  OWNER: "Owner",
  STUDENT: "Student",
};
